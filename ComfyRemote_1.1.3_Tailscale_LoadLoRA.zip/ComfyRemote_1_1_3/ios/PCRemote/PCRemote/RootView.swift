import SwiftUI

struct RootView: View {
    @EnvironmentObject var settings: ConnectionSettings

    var body: some View {
        Group {
            if settings.isConnected {
                ComfyRemoteHomeView()
            } else {
                SetupView()
            }
        }
        .preferredColorScheme(settings.preferredColorScheme)
    }
}

private struct ComfyRemoteHomeView: View {
    @EnvironmentObject var settings: ConnectionSettings
    @State private var model: ComfyUIModel?
    @State private var showSettings = false

    var body: some View {
        Group {
            if let model {
                ComfyUIView(
                    model: model,
                    standalone: true,
                    onSettings: { showSettings = true }
                )
            } else {
                ZStack {
                    Color.black.ignoresSafeArea()
                    ProgressView("Подключаем ComfyUI…")
                        .tint(.white)
                        .foregroundStyle(.white)
                }
            }
        }
        .task(id: settings.currentDevice?.storageKey) {
            guard let device = settings.currentDevice else {
                model = nil
                return
            }
            if model?.device.storageKey != device.storageKey {
                model = ComfyUIModel(device: device)
            }
        }
        .sheet(isPresented: $showSettings) {
            ComfyRemoteSettingsView()
                .environmentObject(settings)
        }
    }
}

private struct ComfyRemoteSettingsView: View {
    @EnvironmentObject var settings: ConnectionSettings
    @Environment(\.dismiss) private var dismiss
    @State private var statusText = ""

    private var client: APIClient? {
        guard let device = settings.currentDevice else { return nil }
        return APIClient(device: device)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("ComfyUI") {
                    HStack(spacing: 12) {
                        Image(systemName: "sparkles.rectangle.stack.fill")
                            .font(.title2)
                            .foregroundStyle(.cyan)
                            .frame(width: 42, height: 42)
                            .background(Color.cyan.opacity(0.12), in: RoundedRectangle(cornerRadius: 12))
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Comfy Remote").font(.headline)
                            Text(settings.currentDevice?.name ?? "Windows PC")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    }
                }

                Section("Подключение") {
                    Picker("Маршрут", selection: $settings.connectionRouteRaw) {
                        ForEach(ConnectionRouteMode.allCases) { mode in
                            Text(mode.title).tag(mode.rawValue)
                        }
                    }
                    if let device = settings.currentDevice {
                        LabeledContent("LAN", value: "\(device.host):\(device.port)")
                        if let zero = device.zerotierHost, !zero.isEmpty {
                            LabeledContent("ZeroTier", value: "\(zero):\(device.port)")
                        }
                        if let tail = device.tailscaleHost, !tail.isEmpty {
                            LabeledContent("Tailscale", value: "\(tail):\(device.port)")
                        }
                    }
                    Button("Проверить соединение") {
                        Task { await testConnection() }
                    }
                    if !statusText.isEmpty {
                        Text(statusText).font(.footnote).foregroundStyle(.secondary)
                    }
                }

                Section("Оформление") {
                    Picker("Внешний вид", selection: $settings.appearanceRaw) {
                        ForEach(AppearanceMode.allCases) { mode in
                            Text(mode.title).tag(mode.rawValue)
                        }
                    }
                }

                Section("О приложении") {
                    LabeledContent("Версия", value: "1.1.3")
                    LabeledContent("Режим", value: "Только ComfyUI")
                }

                Section {
                    Button("Отключиться от ПК", role: .destructive) {
                        settings.disconnect()
                        dismiss()
                    }
                }
            }
            .navigationTitle("Настройки")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Готово") { dismiss() }
                }
            }
        }
    }

    @MainActor
    private func testConnection() async {
        guard let client else { return }
        do {
            let value = try await client.status()
            statusText = "Подключено: \(value.computer)"
        } catch {
            statusText = error.localizedDescription
        }
    }
}
